
// This file is no longer used. jhrg 3/12/15

#include "TestCommon.h"
#include "InternalErr.h"

using namespace libdap ;

#if 0
TestCommon::TestCommon()
{
}

TestCommon::~TestCommon()
{
}
#endif
#if 0
void
TestCommon::set_series_values(bool)
{
    throw InternalErr(__FILE__, __LINE__, "Unimplemented");
}

bool
TestCommon::get_series_values()
{
    throw InternalErr(__FILE__, __LINE__, "Unimplemented");
}
#endif
