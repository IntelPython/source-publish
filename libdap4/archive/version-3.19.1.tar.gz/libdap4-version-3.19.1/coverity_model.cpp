/*
 * coverity_model.cpp
 *
 * This is a placeholder for 'functions', etc. that serve as
 * models to Coverity. These models help suppress false positive
 * responses by the static scanning tool.
 *
 *  Created on: Sep 18, 2015
 *      Author: jimg
 */




