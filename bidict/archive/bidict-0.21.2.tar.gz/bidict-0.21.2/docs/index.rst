.. toctree::
   :hidden:

   Home <home>
   intro
   basic-usage
   other-bidict-types
   extending
   other-functionality
   addendum
   changelog
   api
   learning-from-bidict
   contributors-guide
   code-of-conduct
   thanks

.. include:: home.rst
