Security
========

Please see
`tidelift.com/security <https://tidelift.com/security>`__
for how to report a security issue in bidict.
