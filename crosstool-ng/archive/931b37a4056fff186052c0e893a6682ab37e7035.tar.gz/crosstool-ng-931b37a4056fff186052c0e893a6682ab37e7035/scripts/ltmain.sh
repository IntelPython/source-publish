# Dummy: crosstool-NG currently does not use libtool itself, it just checks
# its presense/version for the build time... Should be checked at the 'ct-ng build'
# time as well then.
:
